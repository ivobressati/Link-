# Migración 4 — Pagos automáticos (acceso habilitado por curso)

Corré esto después de las migraciones 2 y 3.

```sql
-- 1) Qué curso puede ver cada alumno (esto es lo que habilita el acceso real)
create table if not exists enrollments (
  user_id uuid references auth.users(id),
  course_id text references courses(id),
  granted_at timestamptz default now(),
  source text default 'manual', -- 'mercadopago' | 'stripe' | 'manual'
  primary key (user_id, course_id)
);
alter table enrollments enable row level security;
create policy if not exists "allow_all_enrollments" on enrollments for all using (true) with check (true);

-- 2) Datos de checkout en las órdenes (para poder cruzar con el webhook)
alter table orders add column if not exists external_id text;       -- id de pago en MP o Stripe
alter table orders add column if not exists checkout_id text;       -- id de preferencia/sesión
alter table orders add column if not exists buyer_name text;
alter table orders add column if not exists buyer_email text;

-- 3) Índice para buscar rápido la orden desde el webhook
create index if not exists idx_orders_checkout_id on orders (checkout_id);
-- 4) Función para sumar 1 uso a un cupón cuando se aplica en una compra
create or replace function increment_coupon_usage(p_code text)
returns void as $$
  update coupons set used_count = used_count + 1 where code = p_code;
$$ language sql;
```

## Qué cambia con esto

- `academia.html` ahora solo muestra los cursos en los que el alumno tiene una fila en `enrollments`. Ya no alcanza con tener una cuenta — hay que tener el curso habilitado.
- Cuando un pago se aprueba (por el webhook de Mercado Pago o Stripe), el sistema:
  1. Marca la orden como `paid`.
  2. Crea la cuenta del alumno si no existía (usando su email de compra).
  3. Le da acceso al curso (fila en `enrollments`).
  4. Le manda el correo de bienvenida de Supabase con el link para poner su contraseña.

Nada de esto pisa lo que ya tenés en `orders`, `courses` ni `profiles`.
