# Migración 5 — Comunidad (comentarios por clase + anuncios)

Corré esto después de las migraciones anteriores.

```sql
-- 1) Comentarios debajo de cada clase (con respuestas de un nivel)
create table if not exists comments (
  id uuid primary key default gen_random_uuid(),
  course_id text references courses(id),
  module_order int not null,
  user_id uuid references auth.users(id),
  author_name text,
  is_admin boolean default false,
  body text not null,
  parent_id uuid references comments(id),
  created_at timestamptz default now()
);
create index if not exists idx_comments_lookup on comments (course_id, module_order);

-- 2) Anuncios de la academia (los publica Ivo desde el admin)
create table if not exists announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  pinned boolean default false,
  created_at timestamptz default now()
);

-- 3) Permisos (mismo criterio permisivo que ya usás en el resto de la plataforma)
alter table comments enable row level security;
alter table announcements enable row level security;
create policy if not exists "allow_all_comments" on comments for all using (true) with check (true);
create policy if not exists "allow_all_announcements" on announcements for all using (true) with check (true);
```

## Qué habilita esto

- Cada alumno puede comentar y preguntar debajo de cualquier clase, y responder comentarios de otros (un nivel de respuesta, como para no complicar la UI en el celular).
- Cuando comenta el admin (Ivo), su comentario se marca con `is_admin = true` para que se destaque visualmente como respuesta oficial.
- Los **anuncios** son mensajes generales de la academia (no de una clase puntual) que Ivo publica desde el admin y todos los alumnos ven en su panel.

No toca ninguna tabla existente.
