# Migración 2 — Panel de administración (ventas, cupones, certificados, precios)

Corré esto en Supabase → **SQL Editor**, después de haber corrido `MIGRACION-2-CURSOS.md`.

```sql
-- 1) Precio por curso (para poder cambiarlo desde el admin)
alter table courses add column if not exists price numeric default 0;
alter table courses add column if not exists currency text default 'ARS';

-- 2) Ventas / órdenes (Mercado Pago, Stripe o manual mientras no esté el pago automático)
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  student_name text,
  student_email text,
  course_id text references courses(id),
  amount numeric not null default 0,
  currency text default 'ARS',
  method text default 'manual',   -- 'mercadopago' | 'stripe' | 'manual'
  status text default 'pending',  -- 'pending' | 'paid' | 'cancelled'
  coupon_code text,
  created_at timestamptz default now()
);

-- 3) Cupones de descuento
create table if not exists coupons (
  code text primary key,
  discount_type text default 'percent', -- 'percent' | 'fixed'
  discount_value numeric not null,
  active boolean default true,
  max_uses int,
  used_count int default 0,
  expires_at timestamptz,
  created_at timestamptz default now()
);

-- 4) Registro de certificados emitidos
create table if not exists certificates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  student_name text,
  course_id text references courses(id),
  issued_at timestamptz default now()
);

-- 5) Promoción / banner activo en la home
create table if not exists promotions (
  id int primary key default 1,
  active boolean default false,
  title text default '',
  banner_text text default ''
);
insert into promotions (id, active, title, banner_text) values (1, false, '', '')
  on conflict (id) do nothing;

-- 5b) Estado de cuenta para poder suspender/activar alumnos desde el admin
alter table profiles add column if not exists status text default 'active'; -- 'active' | 'suspended'
-- (la columna "role" ya debería existir de la migración original — si no, correr:)
-- alter table profiles add column if not exists role text default 'student';

-- 6) Permisos (mismo criterio permisivo que ya usás en el resto de la plataforma)
alter table orders enable row level security;
alter table coupons enable row level security;
alter table certificates enable row level security;
alter table promotions enable row level security;
create policy if not exists "allow_all_orders" on orders for all using (true) with check (true);
create policy if not exists "allow_all_coupons" on coupons for all using (true) with check (true);
create policy if not exists "allow_all_certificates" on certificates for all using (true) with check (true);
create policy if not exists "allow_all_promotions" on promotions for all using (true) with check (true);
```

## Qué habilita esto

- **Cursos** → ahora tienen precio y moneda editables desde el admin.
- **Ventas** → cada inscripción (manual o vía pago) queda como una fila en `orders`. Mientras no esté integrado Mercado Pago/Stripe, el admin puede crear la orden a mano cuando alguien paga por transferencia o WhatsApp.
- **Cupones** → códigos de descuento reutilizables, con tope de usos y vencimiento opcional.
- **Certificados** → cada vez que un alumno descarga su certificado en `academia.html`, se guarda un registro acá para que lo veas en el admin.
- **Promoción activa** → un banner opcional que se puede activar/desactivar desde el admin (para usar más adelante en la home).

Nada de esto rompe lo que ya tenés — son tablas nuevas, no tocan `clientes`, `gastos`, `profiles`, `modules` ni `progress`.
