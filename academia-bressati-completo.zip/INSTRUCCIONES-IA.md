# Asistente de IA — despliegue

Sigue el mismo mecanismo que los pagos (mirá `INSTRUCCIONES-PAGOS.md` si todavía no instalaste la Supabase CLI).

## Paso 1 — Correr la migración

Corré el SQL de `MIGRACION-6-IA.md` en Supabase → SQL Editor.

## Paso 2 — Conseguir tu clave de Anthropic

1. Entrá a https://console.anthropic.com
2. Creá una cuenta si no tenés, y andá a **API Keys**.
3. Generá una clave nueva y copiala (empieza con `sk-ant-...`).

## Paso 3 — Configurar el secreto y publicar la función

```
supabase secrets set ANTHROPIC_API_KEY=sk-ant-tu-clave
supabase functions deploy ai-assistant
```

## Paso 4 — Pegar la URL de la función en el HTML

La CLI te va a dar una URL como:
`https://TU_PROJECT_REF.supabase.co/functions/v1/ai-assistant`

Reemplazá `__SUPABASE_PROJECT_REF__` por tu project ref en `academia.html` (buscá `AI_FUNCTION_URL`).

## Paso 5 — Cargar contenido

Esto es lo más importante: **el asistente no sabe nada de barbería por sí solo**. Entrá al admin → "Asistente IA" → "+ Agregar contenido" y cargá ahí tu método: técnicas explicadas con tus palabras, errores comunes, respuestas a las preguntas que más te hacen por WhatsApp. Cuanto más completo esté esto, mejor va a responder.

Si un alumno pregunta algo que no está en ese contenido, el asistente lo va a decir honestamente y le va a sugerir escribirte por WhatsApp — no se va a inventar una respuesta.

## Paso 6 — Probar

Iniciá sesión como alumno en `academia.html`, abrí el botón dorado de abajo a la derecha, y probá preguntar algo que sí cargaste y algo que no. Fijate también en el admin, en "Asistente IA", que las preguntas queden registradas.
