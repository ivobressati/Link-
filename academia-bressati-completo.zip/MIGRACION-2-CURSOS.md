# Migración — soporte para 2 cursos + reproductor con progreso

Corré esto en Supabase → **SQL Editor** de tu proyecto de la Academia (el mismo que ya usás en `admin-academia.html`). Es seguro correrlo aunque ya tengas datos: no borra nada existente.

```sql
-- 1) Tabla de cursos (nueva)
create table if not exists courses (
  id text primary key,              -- ej: 'barberia-inicial'
  slug text unique not null,
  title text not null,
  description text,
  "order" int default 1,
  created_at timestamptz default now()
);

-- 2) Vincular módulos existentes a un curso
alter table modules add column if not exists course_id text references courses(id);
alter table modules add column if not exists video_url text;
alter table modules add column if not exists material_url text;
alter table modules add column if not exists description text;

-- 3) Ampliar progreso para que el reproductor recuerde el minuto
alter table progress add column if not exists last_position int default 0;
alter table progress rename column if exists lesson_id to module_order; -- ajustar solo si tu columna se llamaba distinto
alter table progress add constraint if not exists progress_unique unique (user_id, course_id, module_order);

-- 4) Insertar los 2 cursos
insert into courses (id, slug, title, description, "order") values
  ('barberia-inicial', 'barberia-inicial', 'Barbería Inicial',
   'La base completa: técnica, herramientas, atención al cliente y primeros pasos de negocio.', 1),
  ('perfeccionamiento', 'perfeccionamiento', 'Perfeccionamiento',
   'Técnica avanzada y visión de negocio para llevar tu nivel a otra categoría.', 2)
on conflict (id) do nothing;

-- 5) Permisos (RLS) — mismo criterio que ya usás en las otras tablas
alter table courses enable row level security;
create policy if not exists "allow_read_courses" on courses for select using (true);
```

## Después de correr el SQL

1. En **admin-academia.html** vas a poder asignar cada módulo existente a un `course_id` (`barberia-inicial` o `perfeccionamiento`) editando el módulo.
2. Los módulos nuevos que cargues desde el admin deben tener `course_id`, `order` (1, 2, 3...), `video_url` (link directo al mp4 o embed) y opcionalmente `material_url`.
3. En `academia.html` reemplazá `__SUPABASE_URL__` y `__SUPABASE_ANON_KEY__` por las mismas credenciales que ya usás en el resto de la plataforma.
4. Si la tabla `courses` está vacía o no existe todavía, `academia.html` muestra automáticamente los 2 cursos con contenido de ejemplo (`FALLBACK_COURSES` dentro del archivo) para que puedas ver el diseño funcionando antes de cargar contenido real.

## Nota sobre "Perdidos" y comisiones del CRM
Esta migración es independiente del CRM (`bressati-crm.html`) — no toca las tablas `clientes` ni `gastos`.
