# Academia Bressati — Checklist maestra de despliegue

Todo lo que armamos, en el orden en que hay que hacerlo. Marcá cada casillero a medida que avanzás. No hace falta hacerlo todo el mismo día — la plataforma funciona igual (con menos funciones activas) si vas paso a paso.

---

## FASE 0 — Antes de empezar

- [ ] Tener acceso a tu proyecto de Supabase (el mismo que ya usás para `admin-academia.html` / CRM)
- [ ] Tener acceso a tu repo de GitHub (`ivobressati/Enlace-`) y a Netlify
- [ ] Instalar Node.js (https://nodejs.org, versión LTS) si no lo tenés
- [ ] Instalar la Supabase CLI: `npm install -g supabase`
- [ ] `supabase login`
- [ ] `supabase link --project-ref TU_PROJECT_REF` (el ref lo ves en Supabase → Settings → General)

---

## FASE 1 — Base de datos (SQL Editor de Supabase, en este orden)

- [ ] `MIGRACION-2-CURSOS.md` — crea `courses`, vincula `modules` a un curso
- [ ] `MIGRACION-3-ADMIN.md` — `orders`, `coupons`, `certificates`, `promotions`, precios
- [ ] `MIGRACION-4-PAGOS.md` — `enrollments` (el acceso real a cada curso)
- [ ] `MIGRACION-5-COMUNIDAD.md` — `comments`, `announcements`
- [ ] `MIGRACION-6-IA.md` — `knowledge_base`, `ai_messages`

Cada archivo te dice exactamente qué pegar en el SQL Editor. Corrélos en orden porque algunas migraciones dependen de tablas de la anterior.

---

## FASE 2 — Subir los archivos HTML a tu sitio

- [ ] Reemplazar en tu repo: `academia-landing.html`, `academia.html`, `admin-academia.html`
- [ ] En cada uno de esos 3 archivos, reemplazar `__SUPABASE_URL__` y `__SUPABASE_ANON_KEY__` por los datos reales de tu proyecto (Supabase → Settings → API)
- [ ] Hacer commit y push a GitHub → Netlify lo publica solo

En este punto ya tenés la plataforma visualmente completa, con cursos, panel de alumno, admin, comentarios y anuncios — todo funcionando **salvo pagos automáticos, asistente de IA y video protegido**, que necesitan las Edge Functions de la Fase 3.

---

## FASE 3 — Edge Functions (la parte de terminal)

Parado en la carpeta donde tenés `supabase/functions/`:

- [ ] `supabase secrets set MP_ACCESS_TOKEN=...` (Mercado Pago → Credenciales de producción)
- [ ] `supabase secrets set STRIPE_SECRET_KEY=...` (Stripe → Developers → API keys)
- [ ] `supabase secrets set SITE_URL=https://precious-kitten-b7208c.netlify.app`
- [ ] `supabase secrets set ANTHROPIC_API_KEY=...` (console.anthropic.com)
- [ ] `supabase secrets set BUNNY_LIBRARY_ID=...` y `BUNNY_SECURITY_KEY=...` (bunny.net → Stream)

Publicar todas las funciones:

- [ ] `supabase functions deploy create-checkout`
- [ ] `supabase functions deploy mp-webhook --no-verify-jwt`
- [ ] `supabase functions deploy stripe-webhook --no-verify-jwt`
- [ ] `supabase functions deploy ai-assistant`
- [ ] `supabase functions deploy get-video-token`

- [ ] En Stripe Dashboard → Developers → Webhooks, agregar el endpoint `stripe-webhook` y escuchar `checkout.session.completed`. Copiar el signing secret y correr: `supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_...` y volver a publicar `stripe-webhook`.

---

## FASE 4 — Conectar las URLs de las funciones al HTML

Cada función te da una URL tipo `https://TU_PROJECT_REF.supabase.co/functions/v1/nombre-funcion`. Reemplazar `__SUPABASE_PROJECT_REF__` por tu project ref real en:

- [ ] `academia-landing.html` → variable `SUPABASE_FUNCTIONS_URL` (checkout)
- [ ] `academia.html` → variable `AI_FUNCTION_URL` (asistente)
- [ ] `academia.html` → variable `VIDEO_TOKEN_FUNCTION_URL` (video protegido)

Commit + push de nuevo.

---

## FASE 5 — Cargar contenido real

- [ ] Admin → Cursos: crear/editar los 2 cursos con precio real
- [ ] Admin → Cursos → Módulos: cargar cada módulo con su video (GUID de Bunny Stream, ver Fase 6) y material descargable
- [ ] Admin → Asistente IA: cargar tu método, errores comunes y FAQs
- [ ] Admin → Anuncios: publicar un primer mensaje de bienvenida

---

## FASE 6 — Video protegido (Bunny Stream)

- [ ] Crear cuenta en bunny.net → crear una Video Library
- [ ] Subir cada video de cada módulo
- [ ] Copiar el GUID de cada video y pegarlo en el campo de video del módulo, en el admin (NO pegar una URL)

Mirá `INSTRUCCIONES-SEGURIDAD-VIDEO.md` para el detalle completo de esta fase.

---

## FASE 7 — Probar de punta a punta

- [ ] Comprar un curso con una tarjeta de prueba de Mercado Pago y con la de Stripe (`4242 4242 4242 4242`)
- [ ] Verificar que la venta aparezca "paid" en el admin y que llegue el correo de bienvenida
- [ ] Iniciar sesión como ese alumno nuevo y verificar que el curso aparezca habilitado
- [ ] Ver un módulo completo, marcar como completado, y descargar el certificado
- [ ] Verificar que el certificado aparezca en el admin
- [ ] Comentar en una clase y responder como admin
- [ ] Preguntarle algo al asistente de IA que sí cargaste, y algo que no

---

## Si algo no funciona

Es normal que en el primer intento algo falle — son muchas piezas conectándose por primera vez. Pegame el mensaje de error exacto (de la consola del navegador con F12, o de la terminal) y lo resolvemos punto por punto. No hace falta que resuelvas todo en una sola sesión.
