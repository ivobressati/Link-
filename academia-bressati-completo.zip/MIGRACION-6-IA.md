# Migración 6 — Asistente de IA entrenado en tu método

Corré esto después de las migraciones anteriores.

```sql
-- 1) Base de conocimiento curada por vos — es lo ÚNICO que el asistente puede usar para responder
create table if not exists knowledge_base (
  id uuid primary key default gen_random_uuid(),
  course_id text references courses(id), -- opcional: si es null, aplica a toda la academia
  title text not null,
  content text not null,
  created_at timestamptz default now()
);

-- 2) Historial de preguntas y respuestas (para que el alumno vea su chat y vos veas qué preguntan)
create table if not exists ai_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  role text not null, -- 'user' | 'assistant'
  content text not null,
  created_at timestamptz default now()
);

-- 3) Permisos
alter table knowledge_base enable row level security;
alter table ai_messages enable row level security;
create policy if not exists "allow_all_knowledge_base" on knowledge_base for all using (true) with check (true);
create policy if not exists "allow_all_ai_messages" on ai_messages for all using (true) with check (true);
```

## Cómo funciona

El asistente **no improvisa técnica de barbería en general** — solo responde con lo que vos cargues en `knowledge_base` desde el admin (sección "Asistente IA"), más las descripciones de los módulos de los cursos a los que el alumno tiene acceso. Si la pregunta no se puede responder con ese contenido, el asistente lo dice honestamente y sugiere escribirte por WhatsApp — no se inventa una respuesta.

Cuanto más completo cargues el contenido curado (tu método paso a paso, errores comunes, preguntas frecuentes que ya te hicieron por WhatsApp), mejores respuestas va a poder dar.
