# Pagos automáticos — guía de despliegue

Esta parte es distinta a lo que veníamos haciendo: hasta ahora todo era "editar un HTML y subirlo a GitHub". Los pagos necesitan un pequeño backend porque Mercado Pago y Stripe tienen que avisarle a algo que no sea el celular del alumno cuando el pago se aprueba. Ese algo son las **Supabase Edge Functions** que te dejé en la carpeta `supabase/functions/`.

No se pueden "pegar en un HTML". Se suben con una herramienta de línea de comandos, una única vez por función. Es la parte más técnica de todo el proyecto — te lo dejo bien paso a paso.

---

## Paso 0 — Corré la migración SQL

Antes que nada, corré el SQL de `MIGRACION-4-PAGOS.md` en Supabase → SQL Editor (si todavía no lo hiciste).

---

## Paso 1 — Instalar Supabase CLI

En tu compu (Windows), abrí PowerShell y corré:

```
npm install -g supabase
```

Si no tenés Node.js instalado, primero bajalo de https://nodejs.org (versión LTS) y después repetís el comando de arriba.

## Paso 2 — Conectar la CLI a tu proyecto

```
supabase login
```

Esto te va a abrir el navegador para que confirmes con tu cuenta de Supabase.

Después, parado en la carpeta donde tenés estos archivos (`supabase/functions/...`):

```
supabase link --project-ref TU_PROJECT_REF
```

`TU_PROJECT_REF` es el código que aparece en la URL de tu proyecto de Supabase, algo como `uloxovtuudgdtxoltmqj` (lo ves en Supabase → Settings → General).

## Paso 3 — Configurar las claves secretas

Estas claves NUNCA van en el HTML — solo acá, en el servidor de Supabase.

```
supabase secrets set MP_ACCESS_TOKEN=tu_access_token_de_mercadopago
supabase secrets set STRIPE_SECRET_KEY=tu_secret_key_de_stripe
supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_xxxxxxx
supabase secrets set SITE_URL=https://precious-kitten-b7208c.netlify.app
```

**¿Dónde consigo cada clave?**
- `MP_ACCESS_TOKEN` → Mercado Pago → tu cuenta de desarrollador → Credenciales → Credenciales de producción → Access Token.
- `STRIPE_SECRET_KEY` → Stripe Dashboard → Developers → API keys → Secret key.
- `STRIPE_WEBHOOK_SECRET` → lo conseguís en el Paso 5, después de crear el webhook en Stripe.

`SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY` la CLI ya los conoce por el `link` del Paso 2 — no hace falta configurarlos a mano salvo que la CLI te lo pida (ahí los sacás de Supabase → Settings → API).

## Paso 4 — Publicar las 3 funciones

```
supabase functions deploy create-checkout
supabase functions deploy mp-webhook --no-verify-jwt
supabase functions deploy stripe-webhook --no-verify-jwt
```

El `--no-verify-jwt` es necesario en los webhooks porque Mercado Pago y Stripe no mandan el token de Supabase — mandan su propia firma.

Cuando termine, la CLI te va a mostrar una URL para cada función, algo como:
`https://TU_PROJECT_REF.supabase.co/functions/v1/create-checkout`

## Paso 5 — Configurar el webhook en Stripe

1. Entrá a Stripe Dashboard → Developers → Webhooks → **Add endpoint**.
2. Pegá esta URL: `https://TU_PROJECT_REF.supabase.co/functions/v1/stripe-webhook`
3. Evento a escuchar: `checkout.session.completed`
4. Guardá y copiá el **Signing secret** (empieza con `whsec_`).
5. Volvé a la PowerShell y corré: `supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_ese_valor`
6. Volvé a publicar la función para que tome el nuevo secreto: `supabase functions deploy stripe-webhook --no-verify-jwt`

Con Mercado Pago no hace falta configurar nada a mano — `create-checkout` ya le manda la URL del webhook en cada preferencia de pago.

## Paso 6 — Conectar el botón de compra en la home

En `academia-landing.html`, cada botón "Quiero inscribirme" abre un formulario simple (nombre, email, medio de pago) y llama a `create-checkout`. Ya lo dejé armado en el archivo — mirá `MIGRACION-4-PAGOS.md` para los detalles de la tabla `enrollments`, que es la que controla el acceso real a cada curso.

## Paso 7 — Probar

- Mercado Pago tiene un modo de pruebas con tarjetas de test — buscá "tarjetas de prueba Mercado Pago Argentina" en su documentación.
- Stripe también tiene tarjetas de test, la más común es `4242 4242 4242 4242` con cualquier fecha futura y CVC.
- Hacé una compra de prueba de punta a punta: comprá un curso, fijate que la orden pase a "paid" en el panel admin (sección Ventas), que te llegue el correo de bienvenida, y que el curso aparezca en `academia.html`.

---

## Si en algún momento te trabás

Mandame el mensaje de error exacto que te tira la PowerShell o la consola del navegador (F12 → pestaña Console) y seguimos desde ahí. No hace falta que entiendas cada línea de código — con que puedas copiar y pegar los comandos alcanza.
