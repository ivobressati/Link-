# Seguridad de videos — guía de despliegue

## Primero, la verdad completa

No existe forma de garantizar al 100% que un video no se pueda grabar con la pantalla — ninguna plataforma del mundo lo logra, ni Netflix. Lo que sí logramos con esto:

1. **El video nunca tiene un link público fijo.** Cada vez que un alumno entra a una clase, se genera un link que vence en 6 horas y que solo funciona para él.
2. **Marca de agua con nombre y email del alumno**, que se mueve por la pantalla cada 15 segundos. Si alguien graba y comparte, se sabe exactamente de qué cuenta salió.
3. **Sin botón de descarga**, sin clic derecho, sin "guardar video".
4. **Verificación de pago real**: el link firmado solo se genera si el alumno tiene el curso pagado (`enrollments`) — no alcanza con tener una cuenta.

Esto es el mismo nivel de protección que usan las plataformas de cursos online serias (Hotmart, Teachable, etc.).

## Paso 1 — Crear tu cuenta en Bunny Stream

1. Entrá a https://bunny.net y creá una cuenta.
2. Creá una **Video Library** (te va a pedir un nombre, poné "Bressati Academy").
3. Anotá el **Library ID** (Bunny → tu librería → Overview).
4. Andá a la librería → **API** → copiá la **Security Key** (a veces aparece como "Token Authentication Key" — si no la ves, activá "Token Authentication" primero en Security).
5. Activá **"Block direct URL access"** o similar en Security, para que el video no se pueda ver sin el token.

## Paso 2 — Subir tus videos a Bunny

Desde el panel de Bunny Stream, subís cada video de cada módulo. Cuando termine de procesar, cada video tiene un **GUID** (algo como `8f2a1c3d-4b5e-...`) — ese es el dato que vas a pegar en el admin, no una URL.

## Paso 3 — Correr la migración y configurar los secretos

No hace falta una tabla nueva para esto — reutiliza `modules.video_url`, pero ahí ahora va el **GUID de Bunny**, no un link.

```
supabase secrets set BUNNY_LIBRARY_ID=tu_library_id
supabase secrets set BUNNY_SECURITY_KEY=tu_security_key
supabase functions deploy get-video-token
```

## Paso 4 — Pegar la URL de la función en el HTML

Reemplazá `__SUPABASE_PROJECT_REF__` por tu project ref en `academia.html` (buscá `VIDEO_TOKEN_FUNCTION_URL`).

## Paso 5 — Cargar los módulos con el GUID de Bunny

En el admin → Cursos → Módulos → Editar, pegá el GUID de Bunny en el campo de video (no una URL). El sistema detecta automáticamente que no es una URL y pide el link firmado antes de reproducir.

Si en algún módulo dejás una URL directa (`https://...`) en vez del GUID, el sistema lo va a reproducir igual pero SIN la protección de token — solo con el bloqueo básico de descarga y la marca de agua. Es una opción de transición, no la recomendada para el contenido final.

## Paso 6 — Probar

Iniciá sesión como alumno, entrá a un módulo con video de Bunny cargado, y fijate que:
- El video cargue dentro de los 2-3 segundos.
- La marca de agua con tu nombre se vea y se mueva cada 15 segundos.
- Si copiás la URL del iframe y la abrís en otra pestaña sin sesión, no debería funcionar (o debería vencer pronto).
