// supabase/functions/create-checkout/index.ts
//
// Recibe: { course_id, buyer_name, buyer_email, method: 'mercadopago' | 'stripe', coupon_code? }
// Devuelve: { url }  -> el link de pago al que hay que redirigir al alumno
//
// Variables de entorno necesarias (se configuran con `supabase secrets set`):
//   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
//   MP_ACCESS_TOKEN        (Mercado Pago -> Credenciales de producción -> Access Token)
//   STRIPE_SECRET_KEY      (Stripe -> Developers -> API keys -> Secret key)
//   SITE_URL               (ej: https://precious-kitten-b7208c.netlify.app)

import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const MP_ACCESS_TOKEN = Deno.env.get("MP_ACCESS_TOKEN")!;
const STRIPE_SECRET_KEY = Deno.env.get("STRIPE_SECRET_KEY")!;
const SITE_URL = Deno.env.get("SITE_URL") || "https://precious-kitten-b7208c.netlify.app";

const sb = createClient(SUPABASE_URL, SERVICE_ROLE);
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

  try {
    const { course_id, buyer_name, buyer_email, method, coupon_code } = await req.json();

    if (!course_id || !buyer_email || !method) {
      return json({ error: "Faltan datos: course_id, buyer_email y method son obligatorios." }, 400);
    }

    const { data: course, error: courseErr } = await sb
      .from("courses").select("*").eq("id", course_id).single();
    if (courseErr || !course) return json({ error: "Curso no encontrado." }, 404);

    // Aplicar cupón si vino uno
    let amount = Number(course.price || 0);
    let appliedCoupon: string | null = null;
    if (coupon_code) {
      const { data: coupon } = await sb.from("coupons").select("*").eq("code", coupon_code.toUpperCase()).single();
      const valid = coupon && coupon.active
        && (!coupon.max_uses || coupon.used_count < coupon.max_uses)
        && (!coupon.expires_at || new Date(coupon.expires_at) > new Date());
      if (valid) {
        amount = coupon.discount_type === "percent"
          ? amount * (1 - coupon.discount_value / 100)
          : Math.max(0, amount - coupon.discount_value);
        appliedCoupon = coupon.code;
      }
    }
    amount = Math.round(amount * 100) / 100;

    // Crear la orden en estado "pending" — el webhook la marca "paid" cuando se confirme el pago
    const { data: order, error: orderErr } = await sb.from("orders").insert({
      course_id, amount, currency: course.currency || "ARS",
      method, status: "pending",
      buyer_name, buyer_email, coupon_code: appliedCoupon,
    }).select().single();
    if (orderErr) return json({ error: "No se pudo crear la orden." }, 500);

    const successUrl = `${SITE_URL}/academia.html?compra=exito`;
    const cancelUrl = `${SITE_URL}/academia-landing.html?compra=cancelada`;

    if (method === "mercadopago") {
      const resp = await fetch("https://api.mercadopago.com/checkout/preferences", {
        method: "POST",
        headers: { "Authorization": `Bearer ${MP_ACCESS_TOKEN}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          items: [{ title: course.title, quantity: 1, currency_id: course.currency || "ARS", unit_price: amount }],
          payer: { email: buyer_email, name: buyer_name },
          external_reference: order.id,
          back_urls: { success: successUrl, failure: cancelUrl, pending: cancelUrl },
          auto_return: "approved",
          notification_url: `${SUPABASE_URL}/functions/v1/mp-webhook`,
        }),
      });
      const pref = await resp.json();
      if (!pref.init_point) return json({ error: "Mercado Pago no devolvió un link de pago." }, 500);
      await sb.from("orders").update({ checkout_id: pref.id }).eq("id", order.id);
      return json({ url: pref.init_point });
    }

    if (method === "stripe") {
      const params = new URLSearchParams({
        "mode": "payment",
        "success_url": successUrl,
        "cancel_url": cancelUrl,
        "customer_email": buyer_email,
        "line_items[0][price_data][currency]": (course.currency || "ARS").toLowerCase(),
        "line_items[0][price_data][product_data][name]": course.title,
        "line_items[0][price_data][unit_amount]": String(Math.round(amount * 100)),
        "line_items[0][quantity]": "1",
        "metadata[order_id]": order.id,
      });
      const resp = await fetch("https://api.stripe.com/v1/checkout/sessions", {
        method: "POST",
        headers: { "Authorization": `Bearer ${STRIPE_SECRET_KEY}`, "Content-Type": "application/x-www-form-urlencoded" },
        body: params,
      });
      const session = await resp.json();
      if (!session.url) return json({ error: "Stripe no devolvió un link de pago." }, 500);
      await sb.from("orders").update({ checkout_id: session.id }).eq("id", order.id);
      return json({ url: session.url });
    }

    return json({ error: "Método de pago inválido." }, 400);
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}
