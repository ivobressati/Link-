// supabase/functions/mp-webhook/index.ts
//
// Configurar esta URL como "notification_url" en Mercado Pago (ya se manda automáticamente
// desde create-checkout, pero también podés pegarla a mano en tu cuenta de Mercado Pago):
//   https://TU-PROYECTO.supabase.co/functions/v1/mp-webhook

import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const MP_ACCESS_TOKEN = Deno.env.get("MP_ACCESS_TOKEN")!;

const sb = createClient(SUPABASE_URL, SERVICE_ROLE);

Deno.serve(async (req) => {
  try {
    const url = new URL(req.url);
    const topic = url.searchParams.get("topic") || url.searchParams.get("type");
    const id = url.searchParams.get("id") || url.searchParams.get("data.id");

    // Mercado Pago también puede mandar el aviso por body en vez de query params
    let body: any = {};
    try { body = await req.json(); } catch { /* sin body, no pasa nada */ }
    const paymentId = id || body?.data?.id;
    const isPaymentTopic = topic === "payment" || body?.type === "payment";

    if (!isPaymentTopic || !paymentId) return new Response("ignored", { status: 200 });

    const resp = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
      headers: { "Authorization": `Bearer ${MP_ACCESS_TOKEN}` },
    });
    const payment = await resp.json();

    if (payment.status !== "approved") return new Response("not approved yet", { status: 200 });

    const orderId = payment.external_reference;
    if (!orderId) return new Response("no external_reference", { status: 200 });

    const { data: order } = await sb.from("orders").select("*").eq("id", orderId).single();
    if (!order || order.status === "paid") return new Response("ok", { status: 200 });

    await grantAccess(order, payment.id);
    return new Response("ok", { status: 200 });
  } catch (e) {
    console.error(e);
    return new Response("error", { status: 200 }); // 200 para que MP no reintente en loop
  }
});

async function grantAccess(order: any, externalId: string | number) {
  await sb.from("orders").update({ status: "paid", external_id: String(externalId) }).eq("id", order.id);

  // ¿ya existe el alumno? si no, se crea y se le manda el correo de bienvenida
  const { data: existing } = await sb.auth.admin.listUsers();
  let userId = existing.users.find((u: any) => u.email === order.buyer_email)?.id;

  if (!userId) {
    const { data: invited, error } = await sb.auth.admin.inviteUserByEmail(order.buyer_email, {
      data: { full_name: order.buyer_name },
    });
    if (error) { console.error("invite error", error); return; }
    userId = invited.user.id;
    await sb.from("profiles").upsert({ id: userId, full_name: order.buyer_name, email: order.buyer_email, role: "student", status: "active" });
  }

  await sb.from("enrollments").upsert({ user_id: userId, course_id: order.course_id, source: "mercadopago" });

  if (order.coupon_code) {
    await sb.rpc("increment_coupon_usage", { p_code: order.coupon_code }).catch(() => {});
  }
}
