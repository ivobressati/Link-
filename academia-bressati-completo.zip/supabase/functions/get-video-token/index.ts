// supabase/functions/get-video-token/index.ts
//
// Recibe: { course_id, module_order }   (con Authorization: Bearer <access_token del alumno>)
// Devuelve: { embedUrl }  -> válido por 6 horas, específico para ESE alumno y ESA clase
//
// Variables de entorno necesarias:
//   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
//   BUNNY_LIBRARY_ID       (Bunny Stream -> tu librería -> ID)
//   BUNNY_SECURITY_KEY     (Bunny Stream -> tu librería -> API -> Security key / Token authentication key)

import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const BUNNY_LIBRARY_ID = Deno.env.get("BUNNY_LIBRARY_ID")!;
const BUNNY_SECURITY_KEY = Deno.env.get("BUNNY_SECURITY_KEY")!;

const sb = createClient(SUPABASE_URL, SERVICE_ROLE);
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: authErr } = await sb.auth.getUser(token);
    if (authErr || !userData?.user) return json({ error: "Sesión inválida." }, 401);
    const user = userData.user;

    const { course_id, module_order } = await req.json();
    if (!course_id || module_order == null) return json({ error: "Faltan datos." }, 400);

    // Verificar que el alumno realmente pagó este curso — sin esto, cualquiera con
    // el link de la función podría pedir el video de cualquier clase.
    const { data: enrollment } = await sb.from("enrollments")
      .select("*").eq("user_id", user.id).eq("course_id", course_id).maybeSingle();
    if (!enrollment) return json({ error: "No tenés acceso a este curso." }, 403);

    const { data: mod } = await sb.from("modules")
      .select("video_url").eq("course_id", course_id).eq("order", module_order).single();
    if (!mod?.video_url) return json({ error: "Este módulo no tiene video cargado." }, 404);

    // video_url en este esquema debe ser el GUID del video en Bunny Stream (no una URL pública)
    const videoId = mod.video_url.trim();
    const expires = Math.floor(Date.now() / 1000) + 60 * 60 * 6; // 6 horas

    const raw = `${BUNNY_SECURITY_KEY}${videoId}${expires}`;
    const tokenHash = await sha256Hex(raw);

    const embedUrl = `https://iframe.mediadelivery.net/embed/${BUNNY_LIBRARY_ID}/${videoId}` +
      `?token=${tokenHash}&expires=${expires}&autoplay=false`;

    return json({ embedUrl, studentName: userData.user.user_metadata?.full_name || user.email, expires });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});

async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
}
