// supabase/functions/ai-assistant/index.ts
//
// Recibe: { question }  (con el header Authorization: Bearer <access_token del alumno>)
// Devuelve: { answer }
//
// Variables de entorno necesarias:
//   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
//   ANTHROPIC_API_KEY   (console.anthropic.com -> API Keys)

import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY")!;

const sb = createClient(SUPABASE_URL, SERVICE_ROLE);
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: authErr } = await sb.auth.getUser(token);
    if (authErr || !userData?.user) return json({ error: "Sesión inválida. Volvé a iniciar sesión." }, 401);
    const user = userData.user;

    const { question } = await req.json();
    if (!question || question.trim().length < 2) return json({ error: "Escribí una pregunta." }, 400);

    // Cursos a los que el alumno tiene acceso
    const { data: enr } = await sb.from("enrollments").select("course_id").eq("user_id", user.id);
    const courseIds = (enr || []).map((e: any) => e.course_id);

    // Contenido curado: general (course_id null) + específico de sus cursos
    const { data: kb } = await sb.from("knowledge_base").select("*").or(
      courseIds.length ? `course_id.is.null,course_id.in.(${courseIds.join(",")})` : "course_id.is.null"
    );

    // Descripciones de los módulos de sus cursos (dan contexto adicional)
    let moduleContext = "";
    if (courseIds.length) {
      const { data: mods } = await sb.from("modules").select("title,description,course_id").in("course_id", courseIds);
      moduleContext = (mods || []).map((m: any) => `- ${m.title}: ${m.description || ""}`).join("\n");
    }

    const knowledgeText = (kb || []).map((k: any) => `### ${k.title}\n${k.content}`).join("\n\n");

    if (!knowledgeText && !moduleContext) {
      return json({ answer: "Todavía no tengo contenido cargado para responder con precisión. Escribile directamente a Ivo por WhatsApp y te va a responder personalmente." });
    }

    const systemPrompt = `Eres el asistente de Bressati Academy, la academia online de barbería de Ivo Bressati.
Respondé SOLO en base al siguiente contenido curado por Ivo. No inventes técnicas, precios ni datos que no estén acá.
Si la pregunta no se puede responder con este contenido, decilo con honestidad y sugerí escribirle a Ivo por WhatsApp (no inventes una respuesta).
Respondé en español rioplatense, tono cercano y directo, en pocas oraciones.

CONTENIDO CURADO:
${knowledgeText}

DESCRIPCIÓN DE MÓDULOS DEL ALUMNO:
${moduleContext}`;

    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 500,
        system: systemPrompt,
        messages: [{ role: "user", content: question }],
      }),
    });
    const data = await resp.json();
    const answer = data?.content?.find((c: any) => c.type === "text")?.text || "No pude generar una respuesta. Probá de nuevo.";

    await sb.from("ai_messages").insert([
      { user_id: user.id, role: "user", content: question },
      { user_id: user.id, role: "assistant", content: answer },
    ]);

    return json({ answer });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
}
