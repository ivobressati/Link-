// supabase/functions/stripe-webhook/index.ts
//
// Configurar esta URL en Stripe -> Developers -> Webhooks -> Add endpoint:
//   https://TU-PROYECTO.supabase.co/functions/v1/stripe-webhook
// Evento a escuchar: checkout.session.completed
// Copiar el "Signing secret" (empieza con whsec_...) a STRIPE_WEBHOOK_SECRET

import { createClient } from "npm:@supabase/supabase-js@2";
import Stripe from "npm:stripe@14?target=deno";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const STRIPE_SECRET_KEY = Deno.env.get("STRIPE_SECRET_KEY")!;
const STRIPE_WEBHOOK_SECRET = Deno.env.get("STRIPE_WEBHOOK_SECRET")!;

const sb = createClient(SUPABASE_URL, SERVICE_ROLE);
const stripe = new Stripe(STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" });

Deno.serve(async (req) => {
  const signature = req.headers.get("stripe-signature");
  const body = await req.text();

  let event;
  try {
    event = await stripe.webhooks.constructEventAsync(body, signature!, STRIPE_WEBHOOK_SECRET);
  } catch (e) {
    console.error("firma inválida", e);
    return new Response("invalid signature", { status: 400 });
  }

  if (event.type !== "checkout.session.completed") {
    return new Response("ignored", { status: 200 });
  }

  const session = event.data.object as any;
  const orderId = session.metadata?.order_id;
  if (!orderId) return new Response("no order_id", { status: 200 });

  const { data: order } = await sb.from("orders").select("*").eq("id", orderId).single();
  if (!order || order.status === "paid") return new Response("ok", { status: 200 });

  await grantAccess(order, session.id);
  return new Response("ok", { status: 200 });
});

async function grantAccess(order: any, externalId: string) {
  await sb.from("orders").update({ status: "paid", external_id: externalId }).eq("id", order.id);

  const { data: existing } = await sb.auth.admin.listUsers();
  let userId = existing.users.find((u: any) => u.email === order.buyer_email)?.id;

  if (!userId) {
    const { data: invited, error } = await sb.auth.admin.inviteUserByEmail(order.buyer_email, {
      data: { full_name: order.buyer_name },
    });
    if (error) { console.error("invite error", error); return; }
    userId = invited.user.id;
    await sb.from("profiles").upsert({ id: userId, full_name: order.buyer_name, email: order.buyer_email, role: "student", status: "active" });
  }

  await sb.from("enrollments").upsert({ user_id: userId, course_id: order.course_id, source: "stripe" });

  if (order.coupon_code) {
    await sb.rpc("increment_coupon_usage", { p_code: order.coupon_code }).catch(() => {});
  }
}
